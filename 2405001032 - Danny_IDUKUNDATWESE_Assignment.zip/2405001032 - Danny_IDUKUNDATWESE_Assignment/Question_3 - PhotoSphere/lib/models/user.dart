class User {
  final String userId;
  final String username;
  final String avatarUrl;

  User({required this.userId, required this.username, required this.avatarUrl});
}
